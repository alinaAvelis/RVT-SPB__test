'use strict';

// import 'jquery-form-styler';
import headerMenuMobile from './modules/headerMenuMobile';
import showSearchInput from './modules/showSearchInput';
import cutString from './modules/cutString';
import culculator from './modules/culculator';
import radibatton from './modules/radiobatton';


window.addEventListener('DOMContentLoaded', () => {
    // (function($) {
    //     $(function() {
        
    //         $('input, select').styler();
        
    //     });
    // })(jQuery);

    headerMenuMobile("[data-menuMobile]", "[data-mobileOpen]", "[data-close]");

    showSearchInput('[data-opeanSearch]', '[data-closeSearch]', '.logo_link__img ', '[data-mobileOpen]', '#searchBox', '#inputSearch');

    cutString();

    culculator();

    radibatton();
});



