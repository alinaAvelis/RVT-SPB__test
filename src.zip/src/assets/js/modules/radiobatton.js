function radiobatton() {
    const radioBtn = document.querySelector('#maindoor'),
          radioBtnIndicator = document.querySelector('.togler_text');
    
    radioBtn.addEventListener("click", function (evt) { 
        evt.preventDefault();
        radioBtn.getAttribute('aria-checked');
        
        switch(radioBtn.getAttribute('aria-checked')) {
          case "true":
            radioBtn.setAttribute('aria-checked', "false");
            radioBtnIndicator.textContent = "Нет";
              break;
          case "false":
            radioBtn.setAttribute('aria-checked', "true");
            radioBtnIndicator.textContent = "Да";
              break;
        }
      });
}

export default radiobatton;