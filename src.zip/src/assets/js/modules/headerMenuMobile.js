function headerMenuMobile(openedMenu, openButton, closeButton) {
  
  const mobileOpen = document.querySelector(openButton),
         menuMobile = document.querySelector(openedMenu),
         mobileClose = document.querySelector(closeButton);
 
 
   mobileOpen.addEventListener("click", function (evt) { 
     evt.preventDefault();

     menuMobile.classList.add("show");
     mobileOpen.classList.add("hide"); 
   });
 
   mobileClose.addEventListener("click", function (evt) { 
     evt.preventDefault();
     mobileOpen.classList.remove("hide");
     menuMobile.classList.remove("show");
   });
}

export default headerMenuMobile;