function showSearchInput(openButton, closeButton, logoItem, btnMobileMenu, openedSelecor, inputSearch) {
    const openBtn = document.querySelector(openButton),
          closeBtn = document.querySelector(closeButton),
          logo = document.querySelector(logoItem),
          btnOpenMobile = document.querySelector(btnMobileMenu),
          searchBox = document.querySelector(openedSelecor),
          search = searchBox.querySelector(inputSearch),
          searchBoxWidth = parseInt(window.getComputedStyle(search).width);

    if(searchBoxWidth <= 150) {
        search.placeholder = " ";
    }

    openBtn.addEventListener('click', (e)=> {
        e.preventDefault();
        searchBox.classList.add('show');
        logo.classList.add('logo_margin_mobile');
        btnOpenMobile.classList.add('hide');
        openBtn.classList.add('hide');
    });

    closeBtn.addEventListener('click', (e)=> {
        e.preventDefault();
        searchBox.classList.remove('show');
        logo.classList.remove('logo_margin_mobile');
        btnOpenMobile.classList.remove('hide');
        openBtn.classList.remove('hide');
    });
}

export default showSearchInput;