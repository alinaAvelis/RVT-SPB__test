function cutString() {

    const companies = document.querySelector('.best_companies'),
          companiesWidth = parseInt(window.getComputedStyle(companies).width),
          string = document.querySelectorAll(".companies__name");

    let stringArr = [];

    for(let i = 0; i < string.length; i++) {
        string.forEach(s => {
            stringArr[i] = s.innerHTML;
        });
    }   


    if(companiesWidth <= 162) {
        for(let i = 0; i < stringArr.length; i++) {
            string.forEach(s => {
                s.innerHTML = `${stringArr[i].substring(0, 11)}...`;
            });
        } 
    }
}


export default cutString;