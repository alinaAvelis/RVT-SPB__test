function culculator() {
    const result = document.querySelector('#sumNumber'),
          appartmDoor = document.querySelector('#maindoor');

    
    let typeOfAppartment, sqOfAppart, elecntr, perim, repair, ceil, 
    toilet, toiletSq, floor, roomDoor, appartmDoorNumber;

    
    if(localStorage.getItem('typeOfAppartment')) {
        typeOfAppartment = localStorage.getItem('typeOfAppartment');
    } else {
        typeOfAppartment = 6000;
        localStorage.setItem('typeOfAppartment', 6000);
    }

    if(localStorage.getItem('sqOfAppart')) {
        sqOfAppart = localStorage.getItem('sqOfAppart');
    } else {
        sqOfAppart = 42;
        localStorage.setItem('sqOfAppart', 42);
    }

    if(localStorage.getItem('elecntr')) {
        elecntr = localStorage.getItem('elecntr');
    } else {
        elecntr = 0;
        localStorage.setItem('elecntr', 0);
    }

    if(localStorage.getItem('perim')) {
        perim = localStorage.getItem('perim');
    } else {
        perim = 50;
        localStorage.setItem('perim', 50);
    }

    if(localStorage.getItem('repair')) {
        repair = localStorage.getItem('repair');
    } else {
        repair = 0;
        localStorage.setItem('repair', 0);
    }

    if(localStorage.getItem('ceil')) {
        ceil = localStorage.getItem('ceil');
    } else {
        ceil = 0;
        localStorage.setItem('ceil', 0);
    }

    if(localStorage.getItem('toilet')) {
        toilet = localStorage.getItem('toilet');
    } else {
        toilet = 13000;
        localStorage.setItem('toilet', 13000);
    }

    if(localStorage.getItem('toiletSq')) {
        toiletSq = localStorage.getItem('toiletSq');
    } else {
        toiletSq = 42;
        localStorage.setItem('toiletSq', 42);
    }

    if(localStorage.getItem('floor')) {
        floor = localStorage.getItem('floor');
    } else {
        floor = 200;
        localStorage.setItem('floor', 200);
    }

    if(localStorage.getItem('roomDoor')) {
        roomDoor = localStorage.getItem('roomDoor');
    } else {
        roomDoor = 8500;
        localStorage.setItem('roomDoor', 8500);
    }

    if(localStorage.getItem('appartmDoorNumber')) {
        appartmDoorNumber = localStorage.getItem('appartmDoorNumber');
    } else {
        appartmDoorNumber = 0;
        localStorage.setItem('appartmDoorNumber', 0);
    }
 


    function calcTotal() {
        if(!typeOfAppartment || !sqOfAppart || !elecntr || !perim || !repair || !ceil  || !toilet || !floor  || !roomDoor || !roomDoor || !appartmDoor) {
            result.textContent = '____';
            return; 
        } 
        
        result.textContent = Math.round((typeOfAppartment * sqOfAppart) + (elecntr * sqOfAppart) + (repair * sqOfAppart) + (ceil * sqOfAppart) + (toilet * toiletSq) + (floor * sqOfAppart) + roomDoor + appartmDoorNumber);
        
    }  

    getDinamicInformation("#roomType");
    getDinamicInformation("#square");
    getDinamicInformation("#electric");
    getDinamicInformation("#perimeter");
    getDinamicInformation("#repairType");
    getDinamicInformation("#ceilings");
    getDinamicInformation("#wc");
    getDinamicInformation("#squareWs");
    getDinamicInformation("#warmFloor");
    getDinamicInformation("#doors");


    function getDinamicInformation(selector) {
        const input = document.querySelector(selector);

        input.addEventListener('input', () => {
            switch(input.getAttribute('id')) {
                case 'roomType':
                    typeOfAppartment = +input.value;
                    break;
                case 'square':
                    sqOfAppart = +input.value;
                    break;
                case 'electric':
                    elecntr = +input.value;
                    break;
                case 'perimeter':
                    perim = +input.value.replace(/\D/g, "");
                    break;
                case 'repairType':
                    repair = +input.value;
                    break;
                case 'ceilings':
                    ceil = +input.value;
                    break;
                case 'wc':
                    toilet = +input.value;
                    break;
                case 'squareWs':
                    toiletSq = +input.value;
                    break;
                case 'warmFloor':
                    floor = +input.value;
                    break;
                case 'doors':
                    roomDoor = +input.value;
                    break;
            }  

            getRadioBtnInfotm();

            calcTotal();        
        });
    }

    function getRadioBtnInfotm() {
        if(appartmDoor.getAttribute('aria-checked', "true")) {
            appartmDoorNumber = 0.05 * ((typeOfAppartment * sqOfAppart) + (elecntr * sqOfAppart) + (repair * sqOfAppart) + (ceil * sqOfAppart) + (toilet * toiletSq) + (floor * sqOfAppart) + roomDoor);
        } else {
            appartmDoorNumber = 0;
        }

        calcTotal(); 
    }

    // function showRangeNamber(squareInput) {
    //     const rangeParent = document.querySelectorAll('[data-range]');
    
    //     rangeParent.forEach(item => {
    //         const  rangeText = item.querySelector('[data-rangeText]');
    
    //         rangeText.textContent = `${squareInput} кв.м`;
    //     });
    // }

    // showRangeNamber(sqOfAppart);

    // showRangeNamber(toiletSq);
   
}

export default culculator;